import sys
import os

# Force UTF-8 output encoding (Windows CMD uses cp1252 by default, crashes on emoji)
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr and hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Add project root to sys.path so 'backend' module is found
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from flask import Flask, jsonify, request, render_template, session, redirect, send_from_directory
from flask_cors import CORS
try:
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address
    HAS_LIMITER = True
except ImportError:
    HAS_LIMITER = False
from backend.config import Config
from backend.database.models import init_db, SearchHistory, get_db
from backend.services.hybrid_scanner_service import HybridScannerService as ScannerService
from backend.services.watchlist_service import WatchlistService
from backend.security import Security
from datetime import datetime
import atexit
import logging
import re

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
static_folder = os.path.join(project_root, 'frontend')

app = Flask(__name__, static_folder=static_folder, static_url_path='')
app.config.from_object(Config)
CORS(app)
security_service = Security(app)

# XC-7: Rate limiting on login endpoint to prevent brute-force attacks
if HAS_LIMITER:
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=[],            # No global limit — only applied per-route
        storage_uri="memory://",      # In-memory; works fine for single-process Pi deploy
    )
else:
    limiter = None
    logging.getLogger(__name__).warning(
        "flask-limiter not installed — login rate limiting disabled. "
        "Run: pip install flask-limiter>=3.5.0"
    )

# Register paper trading API routes (Phase 3)
from backend.api.paper_routes import paper_bp
app.register_blueprint(paper_bp)

# Initialize database
init_db()

# P1-A12: Validate ENCRYPTION_KEY at startup (needed for Tradier token encryption)
if not Config.ENCRYPTION_KEY:
    logging.getLogger(__name__).warning(
        "ENCRYPTION_KEY not set. Tradier token encryption/decryption will fail. "
        "Set ENCRYPTION_KEY env var for paper trading with Tradier."
    )

# Global service instance
scanner_service = None

def get_scanner():
    global scanner_service
    if scanner_service is None:
        try:
            print("Initializing global ScannerService...", flush=True)
            scanner_service = ScannerService()
            print("ScannerService initialized.", flush=True)
        except Exception as e:
            print(f"Error initializing ScannerService: {e}", flush=True)
            raise e
    return scanner_service

# ...

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    """Login page and API"""
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if security_service.login_user(username, password):
            return jsonify({'success': True})
            
        return jsonify({'success': False, 'error': 'Invalid credentials'}), 401

    # GET request - serve login page
    return app.send_static_file('login.html')

# XC-7: Apply rate limit to login — 5 attempts/minute per IP
# Prevents brute-force attacks on the login endpoint
if limiter is not None:
    login_page = limiter.limit("5/minute")(login_page)

@app.route('/logout')
def logout():
    """Logout user"""
    security_service.logout_user()
    return redirect('/login')

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/me', methods=['GET'])
def get_current_user():
    """Return the logged-in username for frontend display"""
    username = session.get('user')
    if username:
        return jsonify({'success': True, 'username': username})
    return jsonify({'success': False, 'username': None}), 401

# Serve static data files (for tickers.json)
@app.route('/api/data/<path:filename>')
def serve_data(filename):
    data_dir = os.path.join(project_root, 'backend', 'data')
    return send_from_directory(data_dir, filename)

@app.route('/api/watchlist', methods=['GET'])
def get_watchlist():
    """Get current watchlist"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401

        watchlist_service = WatchlistService()
        watchlist = watchlist_service.get_watchlist(current_user)
        watchlist_service.close()
        
        return jsonify({
            'success': True,
            'watchlist': watchlist
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/watchlist', methods=['POST'])
def add_to_watchlist():
    """Add ticker to watchlist"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401

        data = request.get_json()
        ticker = data.get('ticker')
        
        if not ticker:
            return jsonify({
                'success': False,
                'error': 'Ticker is required'
            }), 400
        
        # BUG-2 FIX: Validate ticker format (1-5 uppercase letters only)
        ticker = ticker.strip().upper()
        if not re.match(r'^[A-Z]{1,5}$', ticker):
            return jsonify({
                'success': False,
                'error': f'Invalid ticker format: {ticker}. Use 1-5 letters (e.g. AAPL, MSFT).'
            }), 400
        
        watchlist_service = WatchlistService()
        success, message = watchlist_service.add_ticker(ticker, current_user)
        watchlist_service.close()
        
        return jsonify({
            'success': success,
            'message': message
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/watchlist/<ticker>', methods=['DELETE'])
def remove_from_watchlist(ticker):
    """Remove ticker from watchlist"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401

        watchlist_service = WatchlistService()
        success, message = watchlist_service.remove_ticker(ticker, current_user)
        watchlist_service.close()
        
        return jsonify({
            'success': success,
            'message': message
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan', methods=['POST'])
def run_scan():
    """Run LEAP options scan on watchlist"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401
             
        # Get user's watchlist
        watchlist_service = WatchlistService()
        watchlist = watchlist_service.get_watchlist(current_user)
        watchlist_service.close()
        
        # Override scanner logic to use THIS watchlist, not fetch all from DB inside scanner
        # We need to check if ScannerService.scan_watchlist() supports passing a list.
        # Reading models suggests it might fetch from DB internaly. 
        # Let's check HybridScannerService.scan_watchlist later. 
        # For now, let's assume we might need to update ScannerService OR 
        # manually loop if the scanner service doesn't support list.
        # But wait, looking at past `app.py`, `scanner_service.scan_watchlist()` takes no args.
        # We need to check `HybridScannerService.scan_watchlist` implementation.
        
        # ACTUALLY, strict user segregation means the scanner should ONLY scan what the user has.
        # If `scan_watchlist` pulls ALL tickers from DB, it's wrong.
        # I'll update this route to fetch tickers first, then ask scanner to scan THEM.
        
        # For this step, I will updated run_daily_scan first which explicitly iterates.
        
        scanner_service = ScannerService()
        # Modifying to pass tickers if supported, or we need to update ScannerService
        # Let's assume we will update ScannerService next if needed.
        # For now, let's look at `run_daily_scan` below which DOES iterate.
        
        results = scanner_service.scan_watchlist(username=current_user) # Proposed change to scanner
        scanner_service.close()
        
        return jsonify({
            'success': True,
            'results': results
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan/<ticker>', methods=['POST'])
def scan_ticker(ticker):
    """Run scan on a specific ticker. Supports direction: CALL, PUT, or BOTH (default)."""
    try:
        scanner_service = ScannerService()
        data = request.get_json(silent=True) or {}
        direction = data.get('direction', 'BOTH').upper()
        if direction not in ('CALL', 'PUT', 'BOTH'):
            direction = 'BOTH'

        if direction == 'BOTH':
            # Scan both directions and merge opportunities
            result_call = scanner_service.scan_ticker(ticker, strict_mode=False, direction='CALL')
            result_put = scanner_service.scan_ticker(ticker, strict_mode=False, direction='PUT')

            if result_call and result_put:
                # Merge: use CALL result as base, append PUT opportunities
                merged = dict(result_call)
                call_opps = merged.get('opportunities', [])
                put_opps = result_put.get('opportunities', [])
                merged['opportunities'] = call_opps + put_opps
                result = merged
            elif result_call:
                result = result_call
            elif result_put:
                result = result_put
            else:
                result = None
        else:
            result = scanner_service.scan_ticker(ticker, strict_mode=False, direction=direction)

        scanner_service.close()
        
        if result:
            # Safety net: ensure LEAP opportunities have DTE >= 150
            # (prevents near-term options leaking through stale cache data)
            opps = result.get('opportunities', [])
            from datetime import datetime as dt_check
            now = dt_check.now()
            filtered_opps = []
            for o in opps:
                exp_str = o.get('expiration_date', '')
                try:
                    if isinstance(exp_str, str) and exp_str:
                        exp_dt = dt_check.strptime(exp_str[:10], '%Y-%m-%d')
                        dte = (exp_dt - now).days
                        if dte < 150:
                            continue  # Drop near-term leakers
                        o['days_to_expiry'] = dte  # Ensure consistency
                except:
                    pass
                filtered_opps.append(o)
            result['opportunities'] = filtered_opps

            return jsonify({
                'success': True,
                'result': result
            })
        else:
            return jsonify({
                'success': False,
                'error': f'Ticker {ticker} rejected by filters (MTA/Moat) or data unavailable'
            }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan/daily', methods=['POST'])
def run_daily_scan():
    """Run Daily/Weekly options scan on watchlist"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401
             
        data = request.get_json() or {}
        weeks_out = int(data.get('weeks_out', 0))
        
        # Get user's watchlist to iterate over
        watchlist_service = WatchlistService()
        watchlist = watchlist_service.get_watchlist(current_user)
        watchlist_service.close()
        
        # Service is global
        service = get_scanner()
        
        results = []
        for item in watchlist:
            res = service.scan_weekly_options(item['ticker'], weeks_out=weeks_out)
            if res:
                results.append(res)
        
        return jsonify({
            'success': True,
            'results': results
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan/daily/<ticker>', methods=['POST'])
def scan_ticker_daily(ticker):
    """Run Daily scan on a specific ticker. Already returns both CALL and PUT."""
    try:
        data = request.get_json() or {}
        weeks_out = int(data.get('weeks_out', 0))
        
        service = get_scanner()
        result = service.scan_weekly_options(ticker, weeks_out=weeks_out)
        
        if result:
            return jsonify({
                'success': True,
                'result': result
            })
        else:
            return jsonify({
                'success': False,
                'error': f'No opportunities found for {ticker}'
            }), 200
    except Exception as e:
        print(f"ERROR in scan_ticker_daily: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500



@app.route('/api/tickers', methods=['GET'])
def get_tickers():
    """Get cached full ticker list for autocomplete"""
    try:
        service = get_scanner()
        tickers = service.get_cached_tickers()
        
        return jsonify({
            'success': True,
            'tickers': tickers
        })
    except Exception as e:
        print(f"Error getting tickers: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan/sector', methods=['POST'])
def run_sector_scan():
    """Run Smart Sector Scan"""
    try:
        data = request.get_json() or {}
        sector = data.get('sector')
        
        # safely handle empty strings from frontend
        min_market_cap = int(data.get('min_market_cap') or 0)
        min_volume = int(data.get('min_volume') or 0)
        
        weeks_out = data.get('weeks_out') # None if not provided
        industry = data.get('industry')
        
        if not sector:
             return jsonify({'success': False, 'error': 'Sector is required'}), 400
        
        # F43: Backend validation for 0DTE sector scans (frontend blocks this, but
        # enforce server-side too). 0DTE requires same-day expiry on specific tickers,
        # not broad sector sweeps.
        if weeks_out == 0 or str(weeks_out) == '0':
            return jsonify({
                'success': False,
                'error': '0DTE sector scans are not supported. Use single-ticker 0DTE scan instead.'
            }), 400
        
        service = get_scanner()
        print(f"Starting Sector Scan: {sector} (weeks_out={weeks_out}, industry={industry})", flush=True)
        
        results = service.scan_sector_top_picks(
            sector=sector,
            min_market_cap=min_market_cap,
            min_volume=min_volume,
            weeks_out=weeks_out,
            industry=industry
        )
        
        return jsonify({
            'success': True,
            'results': results
        })
    except Exception as e:
        print(f"Error in sector scan: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get recent search history for current user"""
    try:
        current_user = session.get('user')
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401
             
        db = get_db()
        history = db.query(SearchHistory).filter_by(username=current_user).order_by(SearchHistory.last_searched.desc()).limit(15).all()
        return jsonify({
            'success': True,
            'history': [h.ticker for h in history]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/history', methods=['POST'])
def add_history():
    """Add ticker to search history"""
    try:
        data = request.get_json()
        ticker = data.get('ticker')
        if not ticker:
            return jsonify({'success': False, 'error': 'Ticker required'}), 400
        
        # Backend safety net: reject invalid ticker formats
        ticker = ticker.strip().upper()
        if not re.match(r'^[A-Z]{1,5}$', ticker):
            return jsonify({'success': False, 'error': f'Invalid ticker format: {ticker}'}), 400
            
        db = get_db()
        current_user = session.get('user')
        
        if not current_user:
             return jsonify({'success': False, 'error': 'Not authenticated'}), 401
             
        # Check if exists for this user
        existing = db.query(SearchHistory).filter_by(username=current_user, ticker=ticker).first()
        if existing:
            existing.last_searched = datetime.utcnow()
        else:
            new_entry = SearchHistory(username=current_user, ticker=ticker)
            db.add(new_entry)
            
        db.commit()
        
        # Cleanup old entries (keep top 15 mostly recent PER USER)
        total_count = db.query(SearchHistory).filter_by(username=current_user).count()
        if total_count > 15:
            # Delete oldest for this user
            subquery = db.query(SearchHistory.id).filter_by(username=current_user).order_by(SearchHistory.last_searched.desc()).limit(15)
            db.query(SearchHistory).filter(SearchHistory.username == current_user, ~SearchHistory.id.in_(subquery)).delete(synchronize_session=False)
            db.commit()
            
        return jsonify({'success': True})
    except Exception as e:
        print(f"Error adding history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/analysis/<ticker>', methods=['GET'])
def get_analysis_detail(ticker):
    """Get detailed analysis for a ticker"""
    try:
        service = get_scanner()
        expiry = request.args.get('expiry')  # Optional: from card's expiration_date
        analysis = service.get_detailed_analysis(ticker, expiry_date=expiry)
        
        if analysis:
            return jsonify({
                'success': True,
                'analysis': analysis
            })
        else:
             return jsonify({
                'success': False,
                'error': 'Analysis failed or no data found'
            }), 404
    except Exception as e:
        print(f"Error getting analysis: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/scan/0dte/<ticker>', methods=['POST'])
def scan_0dte(ticker):
    """Run 0DTE scan on a ticker"""
    try:
        service = get_scanner()
        result = service.scan_0dte_options(ticker)
        
        if result:
             return jsonify({'success': True, 'result': result})
        else:
             return jsonify({'success': False, 'error': f'No 0DTE opportunities found for {ticker}'}), 404
    except Exception as e:
        print(f"Error 0DTE scan: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/analysis/ai/<ticker>', methods=['POST'])
def get_ai_analysis_route(ticker):
    """Get AI-Reasoned Analysis for ticker"""
    try:
        data = request.get_json() or {}
        strategy = data.get('strategy', 'LEAP')
        expiry = data.get('expiry')
        
        strike = data.get('strike')
        opt_type = data.get('type')
        
        service = get_scanner()
        # Ensure we block if no API key? Service handles it returning error dict.
        analysis = service.get_ai_analysis(ticker, strategy=strategy, expiry_date=expiry, strike=strike, type=opt_type)
        
        return jsonify({
            'success': True,
            'ai_analysis': analysis
        })
    except Exception as e:
        print(f"Error getting AI analysis: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ═══════════════════════════════════════════════════════════════
# Phase 3: APScheduler — Background Engine
# ═══════════════════════════════════════════════════════════════

def init_scheduler(app):
    """Initialize APScheduler with the monitoring engine jobs.

    Jobs:
      1. sync_tradier_orders   — every 60s  (market hours only)
      2. update_price_snapshots — every 40s  (market hours only)
      3. pre_market_bookend     — Mon-Fri 9:25 AM ET
      4. post_market_bookend    — Mon-Fri 4:05 PM ET
    """
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        from apscheduler.triggers.interval import IntervalTrigger
        from apscheduler.triggers.cron import CronTrigger
        from backend.services.monitor_service import MonitorService
        import pytz

        EASTERN = pytz.timezone('US/Eastern')
        monitor = MonitorService()
        scheduler = BackgroundScheduler(daemon=True)

        # Job 1: Sync order status from Tradier (every 60s)
        scheduler.add_job(
            func=monitor.sync_tradier_orders,
            trigger=IntervalTrigger(seconds=60),
            id='sync_tradier_orders',
            name='Tradier Order Sync (60s)',
            replace_existing=True,
            max_instances=1,
        )

        # Job 2: Update price snapshots via ORATS (every 40s)
        scheduler.add_job(
            func=monitor.update_price_snapshots,
            trigger=IntervalTrigger(seconds=40),
            id='update_price_snapshots',
            name='ORATS Price Snapshots (40s)',
            replace_existing=True,
            max_instances=1,
        )

        # Job 3: Pre-market bookend (9:25 AM ET, Mon-Fri)
        scheduler.add_job(
            func=monitor.capture_bookend_snapshot,
            trigger=CronTrigger(
                day_of_week='mon-fri',
                hour=9,
                minute=25,
                timezone=EASTERN,
            ),
            args=['OPEN_BOOKEND'],
            id='pre_market_bookend',
            name='Pre-Market Bookend (9:25 AM ET)',
            replace_existing=True,
            max_instances=1,  # P2-A3: prevent overlapping bookend runs
        )

        # Job 4: Post-market bookend (4:05 PM ET, Mon-Fri)
        scheduler.add_job(
            func=monitor.capture_bookend_snapshot,
            trigger=CronTrigger(
                day_of_week='mon-fri',
                hour=16,
                minute=5,
                timezone=EASTERN,
            ),
            args=['CLOSE_BOOKEND'],
            id='post_market_bookend',
            name='Post-Market Bookend (4:05 PM ET)',
            replace_existing=True,
            max_instances=1,  # P2-A3: prevent overlapping bookend runs
        )

        # P0-8: Job 5: Lifecycle sync — process stale PENDING/CLOSING trades + expire
        scheduler.add_job(
            func=monitor.lifecycle_sync,
            trigger=IntervalTrigger(seconds=120),
            id='lifecycle_sync',
            name='Lifecycle Sync (120s)',
            replace_existing=True,
            max_instances=1,
        )

        scheduler.start()
        atexit.register(lambda: scheduler.shutdown(wait=False))

        logger = logging.getLogger(__name__)
        logger.info(
            "APScheduler started — 5 jobs registered "
            "(order sync 60s, snapshots 40s, bookends 9:25/16:05 ET, lifecycle 120s)"
        )
        print(
            "\n✅ [SCHEDULER] APScheduler started — 5 background jobs registered:\n"
            "   • sync_tradier_orders  (every 60s)\n"
            "   • update_price_snapshots (every 40s)\n"
            "   • pre_market_bookend   (9:25 AM ET Mon-Fri)\n"
            "   • post_market_bookend  (4:05 PM ET Mon-Fri)\n"
            "   • lifecycle_sync       (every 120s)\n",
            flush=True,
        )

    except ImportError:
        print(
            "\n❌ [SCHEDULER] apscheduler not installed! "
            "Run: pip install apscheduler pytz\n"
            "   Background monitoring engine will NOT run.\n",
            flush=True,
        )
    except Exception as e:
        print(f"\n❌ [SCHEDULER] Failed to start: {e}\n", flush=True)


# Start scheduler unconditionally. APScheduler's replace_existing=True
# prevents duplicate jobs if the module is re-imported.
init_scheduler(app)


if __name__ == '__main__':
    app.run(
        debug=Config.FLASK_DEBUG,
        port=Config.PORT,
        threaded=True
    )
