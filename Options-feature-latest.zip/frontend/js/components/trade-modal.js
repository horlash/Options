/**
 * Trade Modal Component
 * Feature: automated-trading
 * 
 * Handles the trade setup modal: opening, closing, risk calculations,
 * price/qty adjustments, pre-trade checks, and trade confirmation.
 * Phase 4: Wired to paperApi.placeTrade() for live order placement.
 */

const tradeModal = (() => {
    // Live account state (fetched from API when modal opens)
    let accountState = {
        value: 0,
        cash: 0,
        openPositions: 0,
        maxPositions: 5,
        dailyLossUsed: 0,
        dailyLossLimit: 150,
        heatPercent: 0,
        heatLimit: 6.0,
        holdings: []
    };

    let currentTrade = null;

    /**
     * Fetch live account state from the API
     */
    async function _refreshAccountState() {
        try {
            if (typeof paperApi !== 'undefined') {
                const [statsRes, tradesRes] = await Promise.all([
                    paperApi.getStats(),
                    paperApi.getTrades('OPEN'),
                ]);
                if (statsRes && statsRes.success && statsRes.stats) {
                    const s = statsRes.stats;
                    accountState.value = s.portfolio_value || 0;
                    accountState.cash = s.cash_available || 0;
                    accountState.openPositions = s.open_positions || 0;
                    accountState.maxPositions = s.max_positions || 5;
                }
                if (tradesRes && tradesRes.success && tradesRes.trades) {
                    accountState.holdings = tradesRes.trades.map(t => t.ticker);
                }
            }
        } catch (e) {
            console.warn('[trade-modal] Failed to fetch account state:', e);
        }
    }

    /**
 * Open the trade modal with data from a scan result card
 * @param {Object} data - Card data: ticker, price, strike, expiry, daysLeft, premium, type, score, badges
 */
    async function open(data) {
        // Pull SL/TP defaults from portfolio settings
        let slDefault = 0.25, tpDefault = 0.50;
        try {
            if (typeof portfolio !== 'undefined' && portfolio.getState) {
                const pState = portfolio.getState();
                if (pState.defaultSlPct) slDefault = pState.defaultSlPct / 100;
                if (pState.defaultTpPct) tpDefault = pState.defaultTpPct / 100;
            }
        } catch (e) { /* use defaults */ }

        currentTrade = {
            ...data,
            limitPrice: data.premium,
            qty: 1,
            slPercent: slDefault,
            tpPercent: tpDefault
        };

        const modal = document.getElementById('trade-modal-overlay');
        if (!modal) return;

        // ── CREDENTIAL GATE (Issue 3) ──
        // Check if user has broker credentials before allowing trade
        let hasCredentials = false;
        try {
            if (typeof paperApi !== 'undefined') {
                const settingsRes = await paperApi.getSettings();
                if (settingsRes && settingsRes.settings) {
                    hasCredentials = !!settingsRes.settings.has_sandbox_token;
                }
            }
        } catch (e) {
            console.warn('[trade-modal] Failed to check credentials:', e);
        }

        if (!hasCredentials) {
            // Show Setup Broker panel instead of trade form
            _renderCredentialGate(modal, data);
            modal.classList.add('show');
            return;
        }

        // Credentials found — proceed with normal trade flow
        await _refreshAccountState();
        renderModal();
        modal.classList.add('show');
    }

    /**
     * Render the "Setup Broker" panel when credentials are missing
     */
    function _renderCredentialGate(modal, pendingTradeData) {
        modal.innerHTML = `
        <div class="trade-modal" style="max-width: 480px;">
            <div class="modal-header-trade" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
                <h2>🔑 Setup Broker Credentials</h2>
                <button class="modal-close-trade" onclick="tradeModal.close()">×</button>
            </div>
            <div class="modal-body-trade">
                <div style="background: rgba(245,158,11,0.1); padding: 0.75rem 1rem; border-radius: 8px; border-left: 3px solid #f59e0b; margin-bottom: 1.25rem; font-size: 0.85rem; line-height: 1.5;">
                    ⚠️ You need to configure your Tradier API credentials before placing trades. Enter your sandbox API token and Account ID below.
                </div>

                <div style="display: grid; gap: 0.75rem; margin-bottom: 1rem;">
                    <div>
                        <label style="font-size: 0.8rem; color: var(--text-secondary); display: block; margin-bottom: 0.25rem;">Tradier API Token</label>
                        <input type="password" id="cred-gate-token" placeholder="Enter your Tradier sandbox token"
                               style="width: 100%; padding: 0.5rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.15); background: var(--bg-card); color: var(--text-primary); font-size: 0.85rem; box-sizing: border-box;">
                    </div>
                    <div>
                        <label style="font-size: 0.8rem; color: var(--text-secondary); display: block; margin-bottom: 0.25rem;">Account ID</label>
                        <input type="text" id="cred-gate-account" placeholder="Enter your Account ID"
                               style="width: 100%; padding: 0.5rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.15); background: var(--bg-card); color: var(--text-primary); font-size: 0.85rem; box-sizing: border-box;">
                    </div>
                </div>

                <div id="cred-gate-status" style="font-size: 0.8rem; color: var(--text-secondary); min-height: 1.2rem; margin-bottom: 0.75rem;"></div>

                <div style="display: flex; gap: 0.75rem;">
                    <button onclick="tradeModal.close()" 
                            style="flex: 1; padding: 0.6rem; border-radius: 8px; border: 1px solid var(--border); background: var(--bg-card); color: var(--text-light); cursor: pointer; font-size: 0.9rem;">
                        Cancel
                    </button>
                    <button id="cred-gate-save-btn" onclick="tradeModal._saveCredentialsAndProceed()"
                            style="flex: 2; padding: 0.6rem; border-radius: 8px; border: none; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; cursor: pointer; font-size: 0.9rem; font-weight: 600;">
                        🔌 Test & Save Credentials
                    </button>
                </div>
            </div>
        </div>
    `;

        // Store pending trade data for after credential save
        modal._pendingTradeData = pendingTradeData;
    }

    /**
     * Save credentials from the gate panel, test connection, and proceed to trade
     */
    async function _saveCredentialsAndProceed() {
        const token = document.getElementById('cred-gate-token')?.value?.trim();
        const accountId = document.getElementById('cred-gate-account')?.value?.trim();
        const statusEl = document.getElementById('cred-gate-status');
        const saveBtn = document.getElementById('cred-gate-save-btn');

        if (!token || !accountId) {
            if (statusEl) statusEl.innerHTML = '<span style="color: var(--danger);">❌ Both fields are required</span>';
            return;
        }

        // Show saving state
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '⏳ Testing connection...';
            saveBtn.style.opacity = '0.7';
        }

        try {
            if (typeof paperApi !== 'undefined') {
                // Save credentials
                await paperApi.updateSettings({
                    tradier_sandbox_token: token,
                    tradier_account_id: accountId
                });

                // Test connection
                const testRes = await paperApi.testConnection();
                if (testRes && testRes.success) {
                    if (statusEl) statusEl.innerHTML = '<span style="color: var(--secondary);">✅ Connected! Opening trade...</span>';

                    // Brief delay for UX, then proceed to trade
                    setTimeout(async () => {
                        const modal = document.getElementById('trade-modal-overlay');
                        const pendingData = modal?._pendingTradeData;
                        if (pendingData) {
                            // Re-open with credentials now saved
                            await open(pendingData);
                        }
                    }, 800);
                } else {
                    if (statusEl) statusEl.innerHTML = `<span style="color: var(--danger);">❌ Connection failed: ${testRes?.error || 'Unknown error'}</span>`;
                    if (saveBtn) {
                        saveBtn.disabled = false;
                        saveBtn.innerHTML = '🔌 Test & Save Credentials';
                        saveBtn.style.opacity = '1';
                    }
                }
            }
        } catch (err) {
            console.error('[trade-modal] Credential save failed:', err);
            if (statusEl) statusEl.innerHTML = `<span style="color: var(--danger);">❌ Error: ${err.message}</span>`;
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '🔌 Test & Save Credentials';
                saveBtn.style.opacity = '1';
            }
        }
    }

    function close() {
        const modal = document.getElementById('trade-modal-overlay');
        if (modal) modal.classList.remove('show');
        currentTrade = null;
    }

    function renderModal() {
        if (!currentTrade) return;

        const t = currentTrade;
        const isCall = t.type === 'CALL';
        const totalCost = t.limitPrice * t.qty * 100;
        const slPrice = +(t.limitPrice * (1 - t.slPercent)).toFixed(2);
        const tpPrice = +(t.limitPrice * (1 + t.tpPercent)).toFixed(2);
        const maxLoss = +((t.limitPrice - slPrice) * t.qty * 100).toFixed(2);
        const targetProfit = +((tpPrice - t.limitPrice) * t.qty * 100).toFixed(2);
        const riskReward = (targetProfit / maxLoss).toFixed(1);
        const accountPct = accountState.value > 0 ? ((maxLoss / accountState.value) * 100).toFixed(1) : '0.0';
        const heatAfter = accountState.value > 0 ? +(accountState.heatPercent + (totalCost / accountState.value) * 100).toFixed(1) : 0;
        const heatStatus = heatAfter <= accountState.heatLimit ? `within ${accountState.heatLimit}% limit` : `OVER ${accountState.heatLimit}% limit!`;

        // Pre-trade checks
        const checks = [
            { pass: accountState.cash >= totalCost, text: `Buying power sufficient ($${accountState.cash.toLocaleString(undefined, { maximumFractionDigits: 0 })} available)` },
            { pass: true, text: 'Bid-Ask spread: check on broker' },
            { pass: true, text: 'Open Interest: check on broker' },
            { pass: t.daysLeft > 5 || !t.hasEarnings, text: t.hasEarnings ? `⚠️ Earnings within ${t.daysLeft}d` : 'No earnings within 5 days' },
            { pass: accountState.dailyLossUsed + maxLoss <= accountState.dailyLossLimit, text: `Daily loss limit: $${accountState.dailyLossUsed} used of $${accountState.dailyLossLimit}` },
            { pass: !accountState.holdings.includes(t.ticker), text: `No duplicate position for ${t.ticker}` }
        ];

        const actionClass = isCall ? 'order-action-call' : 'order-action-put';
        const actionText = isCall ? 'BUY CALL' : 'BUY PUT';

        const html = `
            <div class="trade-modal">
                <div class="modal-header-trade">
                    <h2>⚡ Trade Setup</h2>
                    <button class="modal-close-trade" onclick="tradeModal.close()">×</button>
                </div>
                <div class="modal-body-trade">
                    <!-- AI Warning Banner (if present) -->
                    ${t.aiWarning ? `
                    <div style="background: rgba(255,77,77,0.1); border: 1px solid var(--danger); border-radius: var(--radius-sm); padding: 0.75rem 1rem; margin-bottom: 0.75rem; font-size: 0.9rem; color: var(--danger); font-weight: 600;">
                        ${t.aiWarning}
                    </div>` : ''}

                    <!-- Order Summary -->
                    <div class="order-summary-bar">
                        <div>
                            <span class="order-ticker">${t.ticker}</span>
                            <span class="order-action-badge ${actionClass}">${actionText}</span>
                        </div>
                        <div style="text-align: right; display: flex; gap: 1rem; align-items: center;">
                            ${t.cardScore ? `
                            <div style="text-align: center;">
                                <div style="font-size: 0.7rem; color: var(--text-muted);">Card</div>
                                <div style="font-size: 1.1rem; font-weight: 700; color: var(--text-muted);">${Math.round(t.cardScore)}</div>
                            </div>` : ''}
                            <div style="text-align: center;">
                                <div style="font-size: 0.7rem; color: var(--text-muted);">${t.aiConviction ? 'AI' : 'Score'}</div>
                                <div style="font-size: 1.5rem; font-weight: 800; color: ${t.score >= 65 ? 'var(--secondary)' : t.score >= 40 ? 'var(--accent)' : 'var(--danger)'};">${Math.round(t.score)}</div>
                            </div>
                            ${t.aiConviction ? `
                            <div style="font-size: 0.75rem; font-weight: 700; color: ${t.score >= 65 ? 'var(--secondary)' : t.score >= 40 ? 'var(--accent)' : 'var(--danger)'};">${t.score >= 65 ? 'PROCEED ✅' : t.score >= 40 ? 'CAUTION ⚠️' : 'AVOID 🚫'}</div>` : ''}
                        </div>
                    </div>

                    <!-- Entry -->
                    <div class="form-section">
                        <div class="form-section-title">Entry</div>
                        <div class="form-row">
                            <div class="form-group">
                                <span class="form-label">Strike Price</span>
                                <input class="form-input" value="$${t.strike}" readonly style="color: var(--primary-light);">
                            </div>
                            <div class="form-group">
                                <span class="form-label">Expiry</span>
                                <input class="form-input" value="${t.expiry} (${t.daysLeft}d)" readonly>
                            </div>
                        </div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.5rem; margin-top:0.5rem;">
                            <div class="form-group">
                                <span class="form-label">Limit Price (Mid)</span>
                                <div class="input-with-adjust">
                                    <button class="adjust-btn" onclick="tradeModal.adjustPrice(-0.05)">−</button>
                                    <input class="form-input" value="$${t.limitPrice.toFixed(2)}" id="modal-limit-price" readonly>
                                    <button class="adjust-btn" onclick="tradeModal.adjustPrice(0.05)">+</button>
                                </div>
                            </div>
                            <div class="form-group">
                                <span class="form-label">Qty</span>
                                <div class="input-with-adjust">
                                    <button class="adjust-btn" onclick="tradeModal.adjustQty(-1)">−</button>
                                    <input class="form-input" value="${t.qty}" id="modal-qty" readonly>
                                    <button class="adjust-btn" onclick="tradeModal.adjustQty(1)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bracket Orders -->
                    <div class="form-section">
                        <div class="form-section-title">Bracket Orders (Auto-Attached)</div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.5rem;">
                            <div class="form-group">
                                <span class="form-label">Stop Loss (-${(t.slPercent * 100).toFixed(0)}%)</span>
                                <div class="input-with-adjust">
                                    <button class="adjust-btn" onclick="tradeModal.adjustSL(-0.05)">−</button>
                                    <input class="form-input" value="$${slPrice.toFixed(2)}" style="color: var(--danger);" readonly>
                                    <button class="adjust-btn" onclick="tradeModal.adjustSL(0.05)">+</button>
                                </div>
                            </div>
                            <div class="form-group">
                                <span class="form-label">Take Profit (+${(t.tpPercent * 100).toFixed(0)}%)</span>
                                <div class="input-with-adjust">
                                    <button class="adjust-btn" onclick="tradeModal.adjustTP(-0.05)">−</button>
                                    <input class="form-input" value="$${tpPrice.toFixed(2)}" style="color: var(--secondary);" readonly>
                                    <button class="adjust-btn" onclick="tradeModal.adjustTP(0.05)">+</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Risk Analysis -->
                    <div class="risk-summary">
                        <div class="risk-summary-title">Risk Analysis</div>
                        <div class="risk-row">
                            <span class="risk-label">Total Cost</span>
                            <span class="risk-value">$${totalCost.toFixed(2)} (${t.qty} × $${t.limitPrice.toFixed(2)} × 100)</span>
                        </div>
                        <div class="risk-row">
                            <span class="risk-label">Max Loss (if SL hits)</span>
                            <span class="risk-value danger">-$${maxLoss.toFixed(2)} (${accountPct}% of account)</span>
                        </div>
                        <div class="risk-row">
                            <span class="risk-label">Target Profit</span>
                            <span class="risk-value success">+$${targetProfit.toFixed(2)} (+${(t.tpPercent * 100).toFixed(0)}%)</span>
                        </div>
                        <div class="risk-row">
                            <span class="risk-label">Risk : Reward</span>
                            <span class="risk-value ${parseFloat(riskReward) >= 1.5 ? 'success' : 'warning'}">1 : ${riskReward} ${parseFloat(riskReward) >= 1.5 ? '✅' : '⚠️'}</span>
                        </div>
                        <div class="risk-row">
                            <span class="risk-label">Portfolio Heat After</span>
                            <span class="risk-value ${heatAfter <= accountState.heatLimit ? 'warning' : 'danger'}">${heatAfter}% → ${heatStatus}</span>
                        </div>
                    </div>

                    <!-- Pre-Trade Checks -->
                    <div class="checks-list">
                        ${checks.map(c => `
                            <div class="check-item">
                                <span class="check-icon">${c.pass ? '✅' : '❌'}</span>
                                <span>${c.text}</span>
                            </div>
                        `).join('')}
                    </div>

                    <!-- Confirm -->
                    <div class="confirm-section">
                        <div class="confirm-warning">⚠️ YOU ARE ABOUT TO SPEND $${totalCost.toFixed(2)}<br>Max Risk: $${maxLoss.toFixed(2)}</div>
                        <button class="confirm-btn" onclick="tradeModal.confirm()">
                            ✅ CONFIRM TRADE — ${actionText} ${t.qty}x ${t.ticker}
                        </button>
                        <div class="confirm-hint">Enter to Confirm | Esc to Cancel</div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('trade-modal-overlay').innerHTML = html;
    }

    function adjustPrice(delta) {
        if (!currentTrade) return;
        currentTrade.limitPrice = Math.max(0.05, +(currentTrade.limitPrice + delta).toFixed(2));
        renderModal();
    }

    function adjustQty(delta) {
        if (!currentTrade) return;
        currentTrade.qty = Math.max(1, Math.min(10, currentTrade.qty + delta));
        renderModal();
    }

    function adjustSL(delta) {
        if (!currentTrade) return;
        const newSL = +(currentTrade.limitPrice * (1 - currentTrade.slPercent) + delta).toFixed(2);
        if (newSL > 0 && newSL < currentTrade.limitPrice) {
            currentTrade.slPercent = +((1 - newSL / currentTrade.limitPrice)).toFixed(4);
            renderModal();
        }
    }

    function adjustTP(delta) {
        if (!currentTrade) return;
        const newTP = +(currentTrade.limitPrice * (1 + currentTrade.tpPercent) + delta).toFixed(2);
        if (newTP > currentTrade.limitPrice) {
            currentTrade.tpPercent = +((newTP / currentTrade.limitPrice - 1)).toFixed(4);
            renderModal();
        }
    }

    function confirm() {
        if (!currentTrade) return;

        // Live-trade confirmation gate
        let requireConfirm = false;
        let isLive = false;
        try {
            if (typeof portfolio !== 'undefined' && portfolio.getState) {
                const pState = portfolio.getState();
                isLive = pState.brokerMode === 'TRADIER_LIVE';
                requireConfirm = isLive && pState.requireTradeConfirm;
            }
        } catch (e) { /* proceed without confirmation */ }

        if (requireConfirm) {
            // Show confirmation modal for live trading
            _showLiveConfirmation();
            return;
        }

        _executeTrade();
    }

    function _showLiveConfirmation() {
        const t = currentTrade;
        if (!t) return;
        const totalCost = (t.limitPrice * t.qty * 100).toFixed(2);
        const actionText = t.type === 'CALL' ? 'BUY CALL' : 'BUY PUT';

        if (typeof showModal === 'function') {
            showModal({
                title: '⚠️ Confirm Live Trade',
                context: `You are about to place a REAL trade: ${actionText} ${t.qty}x ${t.ticker} $${t.strike} @ $${t.limitPrice.toFixed(2)}`,
                warning: `<strong>Total cost: $${totalCost}</strong><br>This will use real money through your broker.`,
                checkboxLabel: 'I confirm this is a real-money trade',
                confirmLabel: `Place Live Trade ($${totalCost})`,
                confirmClass: 'modal-btn modal-btn-danger',
                onConfirm: () => _executeTrade(),
                onCancel: () => { /* user cancelled */ },
            });
        } else {
            // Fallback: browser confirm
            if (window.confirm(`LIVE TRADE: ${actionText} ${t.qty}x ${t.ticker} $${t.strike} @ $${t.limitPrice.toFixed(2)}\nTotal: $${totalCost}\n\nAre you sure?`)) {
                _executeTrade();
            }
        }
    }

    function _executeTrade() {
        if (!currentTrade) return;
        const t = currentTrade;
        const isCall = t.type === 'CALL';
        const actionText = isCall ? 'BUY CALL' : 'BUY PUT';
        const slPrice = +(t.limitPrice * (1 - t.slPercent)).toFixed(2);
        const tpPrice = +(t.limitPrice * (1 + t.tpPercent)).toFixed(2);

        close();

        // Build trade payload with full scanner context
        const tradeData = {
            ticker: t.ticker,
            option_type: t.type,
            strike: t.strike,
            expiry: t.expiry,
            entry_price: t.limitPrice,
            qty: t.qty,
            direction: 'BUY',
            sl_price: slPrice,
            tp_price: tpPrice,
            strategy: t.strategy || 'SCANNER',
            card_score: t.cardScore || t.score,
            ai_score: t.aiScore,
            ai_verdict: t.aiVerdict,
            gate_verdict: t.gateVerdict,
            technical_score: t.technicalScore,
            sentiment_score: t.sentimentScore,
            delta_at_entry: t.delta,
            iv_at_entry: t.iv,
            idempotency_key: `${t.ticker}-${t.strike}-${t.expiry}-${Date.now()}`,
        };

        // Show immediate feedback
        showTradeToast('info', '⏳',
            `<span class="toast-bold">Submitting...</span><br>${actionText} ${t.qty}x ${t.ticker} $${t.strike} @ $${t.limitPrice.toFixed(2)}`);

        // Call live API (Phase 4)
        if (typeof paperApi !== 'undefined') {
            // Immediately add pending row to portfolio view
            if (typeof portfolio !== 'undefined' && portfolio.addPendingPosition) {
                portfolio.addPendingPosition({
                    ticker: t.ticker,
                    type: t.type,
                    strike: t.strike,
                    entry: t.limitPrice,
                    current: t.limitPrice,
                    sl: slPrice,
                    tp: tpPrice,
                    qty: t.qty
                });
            }

            paperApi.placeTrade(tradeData).then(res => {
                if (res.success) {
                    const brokerMsg = res.trade?.broker_msg || '';
                    const isBrokerSuccess = brokerMsg.includes('Tradier order') && !brokerMsg.includes('error');
                    const isPaperOnly = brokerMsg.includes('Paper-only');

                    // Primary confirmation toast
                    showTradeToast('success', '✅',
                        `<span class="toast-bold">Order Placed!</span><br>${actionText} ${t.qty}x ${t.ticker} $${t.strike} @ $${t.limitPrice.toFixed(2)}`);

                    // Prominent success popup
                    const brokerStatus = isBrokerSuccess ? '✅ Tradier order confirmed' : isPaperOnly ? '📝 Paper-only (broker unavailable)' : '📋 Saved';
                    showTradePopup('success', '✅ Trade Placed Successfully!', `${actionText} ${t.qty}x ${t.ticker} $${t.strike} @ $${t.limitPrice.toFixed(2)}<br><br>Broker: ${brokerStatus}<br>SL: $${slPrice.toFixed(2)} | TP: $${tpPrice.toFixed(2)}`);

                    // Broker status toast
                    setTimeout(() => {
                        if (isBrokerSuccess) {
                            showTradeToast('success', '🔗',
                                `<span class="toast-bold">Tradier Order Confirmed</span><br>${brokerMsg}`);
                        } else if (isPaperOnly) {
                            showTradeToast('info', '📝',
                                `<span class="toast-bold">Paper-Only Mode</span><br>Trade saved locally (broker unavailable)`);
                        }
                    }, 1200);

                    // Bracket confirmation toast
                    setTimeout(() => {
                        showTradeToast('info', '📋',
                            `<span class="toast-bold">Brackets Active</span><br>SL: $${slPrice.toFixed(2)} | TP: $${tpPrice.toFixed(2)}`);
                    }, 2400);

                    // Soft-refresh portfolio data from server
                    if (typeof portfolio !== 'undefined' && portfolio.refresh) {
                        setTimeout(() => portfolio.refresh(), 2500);
                    }
                } else {
                    // Server returned success:false
                    const errMsg = res.error || 'Trade was not accepted';
                    showTradeToast('error', '🚫',
                        `<span class="toast-bold">Trade Rejected</span><br>${errMsg}`);
                    showTradePopup('error', '🚫 Trade Rejected', `${errMsg}<br><br>Check Settings → Max Daily Trades if you're hitting the limit.`);
                    if (typeof portfolio !== 'undefined' && portfolio.refresh) {
                        portfolio.refresh();
                    }
                }
            }).catch(err => {
                // Parse specific error types
                let userMsg = err.message || 'Unknown error';
                let alertMsg = userMsg;

                if (userMsg.includes('429') || userMsg.toLowerCase().includes('daily') || userMsg.toLowerCase().includes('limit')) {
                    userMsg = `Daily trade limit reached — ${userMsg}`;
                    alertMsg = `⚠️ Daily Trade Limit Reached\n\n${userMsg}\n\nGo to Settings to adjust your max_daily_trades.`;
                } else if (userMsg.includes('500') || userMsg.includes('server')) {
                    alertMsg = `❌ Server Error\n\n${userMsg}\n\nThe trade may not have been placed. Check Open Positions.`;
                } else if (userMsg.includes('fetch') || userMsg.includes('network') || userMsg.includes('Failed')) {
                    alertMsg = `📡 Connection Error\n\n${userMsg}\n\nCheck your internet connection and try again.`;
                }

                showTradeToast('error', '❌',
                    `<span class="toast-bold">Trade Failed</span><br>${userMsg}`);
                showTradePopup('error', alertMsg.split('\n')[0], userMsg);

                // Remove the pending row since trade wasn't saved
                if (typeof portfolio !== 'undefined' && portfolio.refresh) {
                    portfolio.refresh();
                }
            });
        } else {
            // Fallback: mock portfolio (dev mode)
            if (typeof portfolio !== 'undefined' && portfolio.addPosition) {
                portfolio.addPosition({
                    ticker: t.ticker, type: t.type, strike: t.strike,
                    entry: t.limitPrice, current: t.limitPrice,
                    sl: slPrice, tp: tpPrice
                });
            }
            showTradeToast('success', '✅',
                `<span class="toast-bold">Order Submitted (Mock)</span><br>${actionText} ${t.qty}x ${t.ticker} $${t.strike}`);
        }
    }

    function showTradeToast(type, icon, html) {
        // Use existing toast system if available
        if (typeof toast !== 'undefined' && toast.success) {
            if (type === 'success') toast.success(html.replace(/<[^>]*>/g, ''));
            else if (type === 'info') toast.info ? toast.info(html.replace(/<[^>]*>/g, '')) : toast.success(html.replace(/<[^>]*>/g, ''));
            return;
        }

        // Fallback toast
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        const toastEl = document.createElement('div');
        toastEl.className = `toast ${type}`;
        toastEl.innerHTML = `<span>${icon}</span><span>${html}</span>`;
        container.appendChild(toastEl);
        setTimeout(() => toastEl.remove(), 5000);
    }

    function showTradePopup(type, title, bodyHtml) {
        // Remove existing popup if any
        const existing = document.getElementById('trade-result-popup');
        if (existing) existing.remove();

        const borderColor = type === 'success' ? '#22c55e' : type === 'warning' ? '#eab308' : '#ef4444';
        const bgColor = type === 'success' ? 'rgba(34,197,94,0.1)' : type === 'warning' ? 'rgba(234,179,8,0.1)' : 'rgba(239,68,68,0.1)';
        const iconBg = type === 'success' ? 'rgba(34,197,94,0.2)' : type === 'warning' ? 'rgba(234,179,8,0.2)' : 'rgba(239,68,68,0.2)';

        const overlay = document.createElement('div');
        overlay.id = 'trade-result-popup';
        overlay.style.cssText = `
            position: fixed; inset: 0; z-index: 99999;
            background: rgba(0,0,0,0.6); backdrop-filter: blur(4px);
            display: flex; align-items: center; justify-content: center;
            animation: fadeIn 0.2s ease;
        `;
        overlay.innerHTML = `
            <div style="
                background: #1a1a2e; border: 1px solid ${borderColor};
                border-radius: 16px; padding: 2rem; max-width: 420px; width: 90%;
                box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 30px ${bgColor};
                text-align: center; font-family: inherit;
            ">
                <div style="
                    width: 60px; height: 60px; border-radius: 50%;
                    background: ${iconBg}; display: flex; align-items: center;
                    justify-content: center; margin: 0 auto 1rem;
                    font-size: 1.8rem;
                ">${title.split(' ')[0]}</div>
                <h3 style="color: #fff; margin: 0 0 0.75rem; font-size: 1.2rem;">${title.replace(/^\S+\s/, '')}</h3>
                <div style="color: #a0a0b8; font-size: 0.9rem; line-height: 1.6;">${bodyHtml}</div>
                <button onclick="this.closest('#trade-result-popup').remove()" style="
                    margin-top: 1.5rem; padding: 0.7rem 2.5rem;
                    background: ${borderColor}; color: #fff; border: none;
                    border-radius: 8px; font-weight: 700; font-size: 0.9rem;
                    cursor: pointer; font-family: inherit;
                ">OK</button>
            </div>
        `;
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) overlay.remove();
        });
        document.body.appendChild(overlay);

        // Auto-dismiss after 10 seconds
        setTimeout(() => { if (overlay.parentNode) overlay.remove(); }, 10000);
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        const modal = document.getElementById('trade-modal-overlay');
        if (!modal || !modal.classList.contains('show')) return;

        if (e.key === 'Escape') close();
        if (e.key === 'Enter') confirm();
    });

    return {
        open,
        close,
        confirm,
        adjustPrice,
        adjustQty,
        adjustSL,
        adjustTP,
        _saveCredentialsAndProceed
    };
})();
