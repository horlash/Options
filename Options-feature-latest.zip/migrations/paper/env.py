"""
Alembic Environment Configuration for Paper Trading Migrations
"""

from logging.config import fileConfig
import os
import sys

from sqlalchemy import engine_from_config, pool
from alembic import context

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

# Import models so Alembic can detect them
from backend.database.models import Base
from backend.database import paper_models  # noqa: F401 — registers models with Base

# Alembic Config object
config = context.config

# Override URL from environment if available
db_url = os.getenv('PAPER_TRADE_DB_URL')
if db_url:
    config.set_main_option('sqlalchemy.url', db_url)

# Setup logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Target metadata (shared Base includes both scanner + paper models)
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (SQL output only)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode (connected to database)."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            # Only track paper trading tables, not scanner tables
            include_name=_include_paper_tables,
        )
        with context.begin_transaction():
            context.run_migrations()


def _include_paper_tables(name, type_, parent_names):
    """Filter: only manage paper trading tables in these migrations."""
    if type_ == "table":
        return name in (
            'paper_trades',
            'state_transitions',
            'price_snapshots',
            'user_settings',
        )
    return True


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
